import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsforidComponent } from './detailsforid.component';

describe('DetailsforidComponent', () => {
  let component: DetailsforidComponent;
  let fixture: ComponentFixture<DetailsforidComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DetailsforidComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DetailsforidComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
