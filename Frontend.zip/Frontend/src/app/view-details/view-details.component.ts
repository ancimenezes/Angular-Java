import { Component, OnInit,CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { FormGroup, FormControl, FormArray, Validators, ReactiveFormsModule } from '@angular/forms';
import { ViewDetailsService } from './view-details.service';
import { MatIconModule } from '@angular/material/icon'; 
import { DetailsforidComponent } from '../detailsforid/detailsforid.component';
import { MatDialog } from '@angular/material/dialog';
import {MatGridListModule} from '@angular/material/grid-list';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrl: './view-details.component.scss',
})

export class ViewDetailsComponent implements OnInit {

  loginForm: any;
  
  filter:any;

  displayedColumns: string[] = ['firstname', 'employeeID',
  'designation','salary'];
  dataSource = new MatTableDataSource([]);

  unamePattern = "[a-zA-Z ]*";

  
  
  constructor(public Restiration:ViewDetailsService,public dialog:MatDialog){

  }
    
  ngOnInit() {
        this.loginForm = new FormGroup({
            firstname: new FormControl("",[ Validators.pattern(this.unamePattern),Validators.required]),
            designation:new FormControl("",Validators.required),
            salary:new FormControl("",Validators.required),
        });

        this.GetUsersdata();
    }

    get username() {
      return this.loginForm.get('username');
 } 
    
    registration() {
       
      let submitform={
        "firstname":this.loginForm.get("firstname").value,
        "designation":this.loginForm.get("designation").value,
        "salary":this.loginForm.get("salary").value,
      
      }

      console.log("data",submitform);
      this.apiCall(submitform);
    }


    apiCall(submitform:any){
      this.Restiration.addData(submitform).subscribe((data)=>{
        console.log(data);
        this.GetUsersdata();
      });
    }

    GetUsersdata(){
      this.Restiration.getData().subscribe((data)=>{
        console.log("data",data);
        this.dataSource= new MatTableDataSource(data);

       });
    }

   
      
      
  





applyFilter(event: any) {

  const filterValue = (event.target as HTMLInputElement).value;
  this.dataSource.filter = filterValue.trim().toLowerCase();
}





Clear(){
  this.loginForm.reset();
}

 

}
