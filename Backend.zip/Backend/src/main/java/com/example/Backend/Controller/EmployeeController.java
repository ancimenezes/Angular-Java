package com.example.Backend.Controller;

import com.example.Backend.entity.Employee;

import com.example.Backend.service.EmployeeService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
 
@RestController
public class EmployeeController {
 
    @Autowired
    private EmployeeService employeeService;
   
    @CrossOrigin(origins = "http://localhost:4200")
    @GetMapping("/employees")
    private ResponseEntity<List<Employee>> getEmployeeDetails() {
       
         return ResponseEntity.ok(employeeService.findAll());
    }
 
    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/employees")
    Employee newEmployee(@RequestBody Employee newEmployee) {
      return employeeService.saveEmployee(newEmployee);
    }
 
}


