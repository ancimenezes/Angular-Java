package com.example.Backend.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.Backend.entity.Employee;
import com.example.Backend.repository.EmployeeRepo;
import com.example.Backend.response.EmployeeResponse;
 
public class EmployeeService {
 
    @Autowired
    private EmployeeRepo employeeRepo;
 
    @Autowired
    
 
    public List < Employee > findAll() {
    	Iterable<Employee> findAllIterable = employeeRepo.findAll();
        return mapToList(findAllIterable);
    }

    
    private List<Employee> mapToList(Iterable<Employee> iterable) {
        List<Employee> listofEmployee = new ArrayList<>();
        for (Employee employee : iterable) {
            listofEmployee.add(employee);
        }
        return listofEmployee;
    }
 
    
    public Employee saveEmployee(Employee employee) {
		return this.employeeRepo.save(employee);
		
	}

}