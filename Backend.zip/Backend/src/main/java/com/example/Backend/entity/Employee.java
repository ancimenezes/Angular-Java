package com.example.Backend.entity;
 
import java.sql.Date;

import jakarta.persistence.*;
 
@Entity
@Table(name = "employee")
public class Employee {
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "employeeID")
    private int employeeID;
 
    @Column(name = "firstname")
    private String firstname;
 
    @Column(name = "designation")
    private String designation;
 
    @Column(name = "salary")
    private int salary;
 
   public int getemployeeID() {
        return employeeID;
    }
 
    public void setemployeeID(int employeeID) {
        this.employeeID = employeeID;
    }
 
    public String getfirstname() {
        return firstname;
    }
 
    public void setfirstname(String firstname) {
        this.firstname = firstname;
    }
 
    public String getdesignation() {
        return designation;
    }
 
    public void setdesignation(String designation) {
        this.designation = designation;
    }
 
    public int getsalary() {
        return salary;
    }
 
    public void setsalary(int salary) {
        this.salary = salary;
    }
   
    
}