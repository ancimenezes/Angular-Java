package com.example.Backend.response;

import java.sql.Date;


public class EmployeeResponse {
	
	
    private int employeeID;
 
 
    private String firstname;
 
   
    private String designation;
 
   
    private int salary;
 
     private Date registration;
 
    public int getemployeeID() {
        return employeeID;
    }
 
    public void setemployeeID(int employeeID) {
        this.employeeID = employeeID;
    }
 
    public String getfirstname() {
        return firstname;
    }
 
    public void setfirstname(String firstname) {
        this.firstname = firstname;
    }
 
    public String getdesignation() {
        return designation;
    }
 
    public void setdesignation(String designation) {
        this.designation = designation;
    }
 
    public int getsalary() {
        return salary;
    }
 
    public void setsalary(int salary) {
        this.salary = salary;
    }
    
    public Date getregistration() {
        return registration;
    }
 
    public void setregistration(Date registration) {
        this.registration = registration;
    }
    

}
